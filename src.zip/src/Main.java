import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static Library lib = new Library("Central Library", "Main Campus", 123456789, "central@library.com");

    public static void main(String[] args) {
        // Pre-populate library with books, journals, magazines (composition)
        populateLibrary();

        // Add some members (aggregation)
        Student s1 = new Student("Ahmed Ali", "STD-001", "CS", 20, "ahmed@student.com");
        Teacher t1 = new Teacher("Dr. Khan", "TCH-001", "CS", 45, "khan@teacher.com");
        Member m1 = new Member("Sara Ahmed", "MEM-001", 25, "sara@member.com");
        lib.addStudent(s1);
        lib.addTeacher(t1);
        lib.addMember(m1);

        int choice;
        do {
            System.out.println("\n=== Library Management System ===");
            System.out.println("1. Login as Librarian");
            System.out.println("2. Login as Student");
            System.out.println("3. Login as Teacher");
            System.out.println("4. Login as Member");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {
                case 1:
                    librarianMenu();
                    break;
                case 2:
                    studentMenu(s1);
                    break;
                case 3:
                    teacherMenu(t1);
                    break;
                case 4:
                    memberMenu(m1);
                    break;
                case 5:
                    System.out.println("Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 5);
        sc.close();
    }

    static void populateLibrary() {
        // Using Scanner to add books (composition in Library)
        System.out.println("Initializing library system...");
        // You can manually add books here or uncomment to add via menu
    }

    static void librarianMenu() {
        Librarian librarian = new Librarian("Ali Khan", "LIB-123", 22, "ali@lib.com", 50000);
        int choice;
        do {
            System.out.println("\n--- Librarian Menu ---");
            System.out.println("1. Add Book");
            System.out.println("2. Add Journal");
            System.out.println("3. Add Magazine");
            System.out.println("4. Remove Book");
            System.out.println("5. Show All Books");
            System.out.println("6. Show All Journals");
            System.out.println("7. Show All Magazines");
            System.out.println("8. Issue Book to Student");
            System.out.println("9. Return Book from Student");
            System.out.println("10. Renew Membership");
            System.out.println("11. Search Publication");
            System.out.println("12. Show Library Details");
            System.out.println("13. Back");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {
                case 1:
                    lib.addBook();
                    break;
                case 2:
                    lib.addJournal();
                    break;
                case 3:
                    lib.addMagazine();
                    break;
                case 4:
                    System.out.print("Enter ISBN: ");
                    lib.removeBook(sc.nextLine());
                    break;
                case 5:
                    lib.showAllBooks();
                    break;
                case 6:
                    lib.showAllJournals();
                    break;
                case 7:
                    lib.showAllMagazines();
                    break;
                case 8:
                    System.out.print("Enter Student ID: ");
                    String sid = sc.nextLine();
                    System.out.println("Available Books:");
                    lib.showAllBooks();
                    // This is simplified - in real system you'd find student by ID
                    break;
                case 9:
                    System.out.print("Enter Student ID: ");
                    sid = sc.nextLine();
                    break;
                case 10:
                    System.out.print("Enter Member ID: ");
                    String mid = sc.nextLine();
                    break;
                case 11:
                    System.out.print("Enter title: ");
                    lib.searchPublication(sc.nextLine());
                    break;
                case 12:
                    lib.showLibraryDetails();
                    System.out.println("Total Books: " + Book.getTotalBooks());
                    System.out.println("Total Journals: " + Journal.getTotalJournals());
                    System.out.println("Total Magazines: " + Magazine.getTotalMagazine());
                    break;
                case 13:
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 13);
    }

    static void studentMenu(Student student) {
        Librarian lib = new Librarian("Ali Khan", "LIB-123");
        int choice;
        do {
            System.out.println("\n--- Student Menu ---");
            System.out.println("Welcome, " + student.getName());
            System.out.println("1. Borrow Book");
            System.out.println("2. Return Book");
            System.out.println("3. Report Lost Book");
            System.out.println("4. Pay Due Amount");
            System.out.println("5. Show My Details");
            System.out.println("6. Back");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {
                case 1:
                    Book b = new Book("Java Guide", "Author X", "ISBN-123", true, 500, "English", 1);
                    lib.issueBook(student, b);
                    break;
                case 2:
                    b = new Book("Java Guide", "Author X", "ISBN-123", false, 500, "English", 1);
                    lib.returnBook(student, b);
                    break;
                case 3:
                    System.out.print("Enter ISBN of lost book: ");
                    student.lostBook(sc.nextLine());
                    break;
                case 4:
                    System.out.print("Enter amount: ");
                    student.payDueAmount(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 5:
                    student.showDetails();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 6);
    }

    static void teacherMenu(Teacher teacher) {
        Librarian lib = new Librarian("Ali Khan", "LIB-123");
        int choice;
        do {
            System.out.println("\n--- Teacher Menu ---");
            System.out.println("Welcome, " + teacher.getName());
            System.out.println("1. Borrow Journal");
            System.out.println("2. Return Journal");
            System.out.println("3. Report Lost Journal");
            System.out.println("4. Pay Due Amount");
            System.out.println("5. Show My Details");
            System.out.println("6. Back");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {
                case 1:
                    Journal j = new Journal("AI Journal", "Author Y", "JRN-456", true, 2024, "CS");
                    lib.issueJournal(teacher, j);
                    break;
                case 2:
                    j = new Journal("AI Journal", "Author Y", "JRN-456", false, 2024, "CS");
                    lib.returnJournal(teacher, j);
                    break;
                case 3:
                    System.out.print("Enter title of lost journal: ");
                    teacher.lostJournal(sc.nextLine());
                    break;
                case 4:
                    System.out.print("Enter amount: ");
                    teacher.payDueAmount(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 5:
                    teacher.showDetails();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 6);
    }

    static void memberMenu(Member member) {
        Librarian lib = new Librarian("Ali Khan", "LIB-123");
        int choice;
        do {
            System.out.println("\n--- Member Menu ---");
            System.out.println("Welcome, " + member.getName());
            System.out.println("1. Borrow Magazine");
            System.out.println("2. Return Magazine");
            System.out.println("3. Report Lost Magazine");
            System.out.println("4. Pay Due Amount");
            System.out.println("5. Show My Details");
            System.out.println("6. Back");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {
                case 1:
                    Magazine mag = new Magazine("Tech Weekly", 15, 10, 2024);
                    lib.issueMagazine(member, mag);
                    break;
                case 2:
                    mag = new Magazine("Tech Weekly", 15, 10, 2024);
                    lib.returnMagazine(member, mag);
                    break;
                case 3:
                    System.out.print("Enter name of lost magazine: ");
                    member.lostMagazine(sc.nextLine());
                    break;
                case 4:
                    System.out.print("Enter amount: ");
                    member.payDueAmount(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 5:
                    member.showDetails();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 6);
    }
}